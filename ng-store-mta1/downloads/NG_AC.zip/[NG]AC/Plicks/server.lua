-- ====================================
-- 🔗 CONFIGURACIÓN CENTRAL DESDE SHARED
-- ====================================
-- Asegúrate de que shared.lua esté cargado en meta.xml antes que este archivo

-- ====================================
-- 📤 FUNCIONES DE LOG Y PUNISHMENT
-- ====================================

function removeHex(s)
    if type(s) == "string" then
        while (s ~= s:gsub("#%x%x%x%x%x%x", "")) do
            s = s:gsub("#%x%x%x%x%x%x", "")
        end
    end
    return s or false
end

function sendDiscordLog(optionName, title, playerName, playerSerial, playerIP, reason, punishType)
    local cfg = AntiCheatConfig[optionName]
    if not cfg or not cfg.Webhook then return end

    local punish = punishType or "None"

    local discordData = {
        username = "NG STORE",
        embeds = {
            {
                author = {
                    name = "NG AC Logs",
                    icon_url = "https://media.discordapp.net/attachments/1414475345146675375/1414681357497663498/ChatGPT_Image_4_sept_2025__04_47_31_p.m.-removebg-preview.png?ex=68c0742f&is=68bf22af&hm=f88165ab9a40ebb2dfb2a6619962d822782c0d2a30dc801a732242f984b310a4&=&format=webp&quality=lossless" -- 🔹 tu logo arriba
                },
                title = "NG AC | Log - " .. title,
                color = 0, -- borde negro
                fields = {
                    { name = "Player 👤", value = playerName or "N/A", inline = true },
                    { name = "Punish ⚖️", value = punish, inline = true },

                    { name = "IP 🌐", value = "```"..(playerIP or "N/A").."```", inline = false },
                    { name = "Serial 📌", value = "```"..(playerSerial or "N/A").."```", inline = false },

                    { name = "Reason 🤔", value = "```"..(reason or "Sin razón").."```", inline = false },
                },
                footer = { 
                    text = "NG AC | https://discord.gg/FeP8PDBRHV",
                    icon_url = "https://media.discordapp.net/attachments/1414475345146675375/1414681357497663498/ChatGPT_Image_4_sept_2025__04_47_31_p.m.-removebg-preview.png?ex=68c0742f&is=68bf22af&hm=f88165ab9a40ebb2dfb2a6619962d822782c0d2a30dc801a732242f984b310a4&=&format=webp&quality=lossless" -- 🔹 tu logo abajo
                },
                timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ")
            },
        },
    }

    local jsonData = toJSON(discordData)
    jsonData = string.sub(jsonData, 3, #jsonData - 2)

    fetchRemote(cfg.Webhook, {
        headers = { ["Content-Type"] = "application/json" },
        postData = jsonData
    }, function() end)
end

function logPlayerEvent(optionName, title, player, reason, punishType)
    local playerName = removeHex(getPlayerName(player))
    local playerSerial = getPlayerSerial(player)
    local playerIP = getPlayerIP(player)

    sendDiscordLog(optionName, title, playerName, playerSerial, playerIP, reason, punishType)
end

-- ====================================
-- CASTIGOS
-- ====================================
local function punishPlayer(player, optionName, reason)
    local cfg = AntiCheatConfig[optionName]
    if not cfg or not cfg.State then return end

    local playerName = removeHex(getPlayerName(player))
    local playerSerial = getPlayerSerial(player)
    local playerIP = getPlayerIP(player)

    if cfg.PunishType == "Kick" then
        kickPlayer(player, "NG AC", reason)
        sendDiscordLog(optionName, optionName, playerName, playerSerial, playerIP, reason, "Kick")
    elseif cfg.PunishType == "Ban" then
        banPlayer(player, true, true, true, "NG AC", reason)
        sendDiscordLog(optionName, optionName, playerName, playerSerial, playerIP, reason, "Ban")
    else
        sendDiscordLog(optionName, optionName, playerName, playerSerial, playerIP, reason, "None")
    end
end

-- ====================================
-- 🚫 Remover armas prohibidas
-- ====================================
setTimer(function()
    local cfg = AntiCheatConfig["Anti - Remove Weapons"]
    if not cfg or not cfg.State then return end

    for _, player in ipairs(getElementsByType("player")) do
        if isElement(player) then
            for _, weaponData in ipairs(BlockedWeapons) do
                local weaponID, enabled, weaponName = unpack(weaponData)
                if enabled then
                    if getPedWeapon(player) == weaponID and getPedTotalAmmo(player) > 0 then
                        takeWeapon(player, weaponID)
                        logPlayerEvent("Anti - Remove Weapons", "Arma removida", player, "Intentó usar arma prohibida: " .. weaponName, cfg.PunishType)

                        if cfg.PunishType == "Kick" then
                            kickPlayer(player, "NG AC", "Intento de usar arma prohibida: " .. weaponName)
                        elseif cfg.PunishType == "Ban" then
                            banPlayer(player, true, true, true, "NG AC", "Intento de usar arma prohibida: " .. weaponName)
                        end
                    end
                end
            end
        end
    end
end, 2000, 0)

-- ====================================
-- 💣 Remover explosivos prohibidos
-- ====================================
setTimer(function()
    local cfg = AntiCheatConfig["Anti - Remove Explosives"]
    if not cfg or not cfg.State then return end

    for _, player in ipairs(getElementsByType("player")) do
        if isElement(player) then
            for _, weaponData in ipairs(BlockedExplosives) do
                local weaponID, enabled, weaponName = unpack(weaponData)
                if enabled then
                    if getPedWeapon(player) == weaponID and getPedTotalAmmo(player) > 0 then
                        takeWeapon(player, weaponID)
                        logPlayerEvent("Anti - Remove Explosives", "Explosivo removido", player, "Intentó usar explosivo prohibido: " .. weaponName, cfg.PunishType)

                        if cfg.PunishType == "Kick" then
                            kickPlayer(player, "NG AC", "Intento de usar explosivo prohibido: " .. weaponName)
                        elseif cfg.PunishType == "Ban" then
                            banPlayer(player, true, true, true, "NG AC", "Intento de usar explosivo prohibido: " .. weaponName)
                        end
                    end
                end
            end
        end
    end
end, 2000, 0)

-- ====================================
-- 🔎 EVENTOS ANTICHEAT
-- ====================================
addEventHandler("onElementDataChange", root, function(dataName)
    if client and not isElementDataWhitelisted(dataName) then
        punishPlayer(client, "Anti - ElementData", "Intento de modificar elementData no permitido: " .. dataName)
        cancelEvent()
    end
end)

addEvent("banstopresources", true)
addEventHandler("banstopresources", resourceRoot, function()
    if client then
        punishPlayer(client, "Anti - Stop Resources", "Intento de detener recursos del servidor")
    end
end)

addEventHandler("onPlayerTriggerEventThreshold", root, function()
    punishPlayer(source, "Anti - Trigger Spam", "Spam de eventos detectado")
end)

addEvent("deteccionpegado", true)
addEventHandler("deteccionpegado", resourceRoot, function(text)
    if client then
        punishPlayer(client, "Anti - Paste Detection", "Pegado de código sospechoso detectado: " .. (text or "No text"))
    end
end)

addEventHandler("onExplosion", root, function(explosionType, _, _, _, responsibleElement)
    if responsibleElement and getElementType(responsibleElement) == "player" then
        punishPlayer(responsibleElement, "Anti - Explosions", "Intento de crear explosión no permitido: Type " .. tostring(explosionType))
        cancelEvent()
    end
end)

addEventHandler("onVehicleExplode", root, function(vehicle)
    if vehicle and getElementType(vehicle) == "vehicle" then
        local driver = getVehicleOccupant(vehicle)
        if driver and getElementType(driver) == "player" then
            punishPlayer(driver, "Anti - Vehicle Explosions", "Intento de explosión de vehículo no permitido")
            cancelEvent()
        end
    end
end)

setTimer(function()
    local cfg = AntiCheatConfig["Anti - Godmode"]
    if not cfg or not cfg.State then return end

    for _, player in ipairs(getElementsByType("player")) do 
        if getElementHealth(player) > 100 then
            punishPlayer(player, "Anti - Godmode", "Uso de godmode detectado")
        end
    end
end, 1000, 0)

setTimer(function()
    local cfg = AntiCheatConfig["Anti - Vehicle Health"]
    if not cfg or not cfg.State then return end

    for _, player in ipairs(getElementsByType("player")) do 
        local veh = getPedOccupiedVehicle(player)
        if isElement(veh) then
            local driver = getVehicleOccupant(veh, 0)
            if driver == player and getElementHealth(veh) > 1000 then
                punishPlayer(player, "Anti - Vehicle Health", "Uso no autorizado de vehículo con más de 1000 de vida")
            end
        end
    end
end, 1000, 0)

-- ====================================
-- 👤 Logs de conexión
-- ====================================
addEventHandler("onPlayerJoin", root, function()
    local cfg = AntiCheatConfig["Player Join/Quit"]
    if not cfg or not cfg.State then return end

    local playerName = removeHex(getPlayerName(source))
    local playerSerial = getPlayerSerial(source)
    local playerIP = getPlayerIP(source)

    sendDiscordLog("Player Join/Quit", "PlayerJoin", playerName, playerSerial, playerIP, "El Usuario se conectó al servidor", "None")
end)

addEventHandler("onPlayerQuit", root, function(reason)
    local cfg = AntiCheatConfig["Player Join/Quit"]
    if not cfg or not cfg.State then return end

    local playerName = removeHex(getPlayerName(source))
    local playerSerial = getPlayerSerial(source)
    local playerIP = getPlayerIP(source)

    sendDiscordLog("Player Join/Quit", "PlayerQuit", playerName, playerSerial, playerIP, "El Usuario salió del servidor Razón: " .. tostring(reason), "None")
end)

-- ====================================
-- 🔒 Protección de IP del servidor
-- ====================================
local allowedIP = "51.81.57.217"

addEventHandler("onResourceStart", resourceRoot, function()
    fetchRemote("http://api.ipify.org", function(response, errno)
        if errno == 0 and response then
            local ip = response:gsub("%s+", "")
            if ip ~= allowedIP then
                outputDebugString("[PROTECCIÓN] IP NO autorizada: " .. ip)
                stopResource(getThisResource())
            else
                outputDebugString("[PROTECCIÓN] Servidor autorizado con IP: " .. ip)
            end
        else
            outputDebugString("[PROTECCIÓN] No se pudo verificar la IP pública. Deteniendo resource.")
            stopResource(getThisResource())
        end
    end)
end)

outputDebugString("✅ NG AC cargado con configuración desde shared.lua (logs estilizados + logo)")
