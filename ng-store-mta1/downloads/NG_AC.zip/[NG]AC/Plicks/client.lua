addEventHandler("onClientResourceStop", resourceRoot, function()
    triggerServerEvent("banstopresources", resourceRoot)
end)

local funcionesbloqueadas = {
    'outputChatBox',
    'getAllElementData',
    'function',
    'triggerEvent',
    'triggerClientEvent',
    'triggerServerEvent',
    'setElementData',
    'addEvent',
    'addEventHandler',
    'addDebugHook',
    'createExplosion',
    'createProjectile',
    'setElementPosition',
    'createVehicle',
    'setElementHealth',
    'setPedArmor',
}

addEventHandler("onClientPaste", root, function(text)
    for index , v in ipairs(funcionesbloqueadas) do
        if text:find(v) then
            triggerServerEvent("deteccionpegado", resourceRoot, text)
        end
    end
end)

addEventHandler("onClientProjectileCreation", root, function(creator)
    local projectileType = getProjectileType(source)
    if projectileType == 17 or projectileType == 39 or projectileType == 16 or projectileType == 18 or projectileType == 19 or projectileType == 20 or projectileType == 21 or projectileType == 58 then
        destroyElement(source)
    end
end)

function cancelSatchelExplosionDamage(attacker, weapon, bodypart, loss)
    if weapon == 39 then
        cancelEvent()
    end
end
addEventHandler("onClientPlayerDamage", localPlayer, cancelSatchelExplosionDamage)

addEventHandler("onClientResourceStart", resourceRoot, function()
    triggerServerEvent("onClientLoadedAntiCheat", resourceRoot)
end)