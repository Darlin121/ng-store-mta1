token_user = "Token"

-- ====================================
-- ⚙️ CONFIGURACIÓN ANTICHEAT CENTRAL
-- ====================================

AntiCheatConfig = {
    ["Anti - ElementData"] = {
        ["State"] = true,
        ["PunishType"] = "Kick", -- Kick, Ban o None
        ["Webhook"] = "https://discordapp.com/api/webhooks/1414664290413314169/OfO11OcYgAEAsWbdAOmJH_NIj7u074tgxC-kvN2T1b5M71Fwe5c0ilyWWnkEOpwnClYL"
    },
    ["Anti - ACL"] = {
        ["State"] = true,
        ["PunishType"] = "Ban",
        ["Webhook"] = "https://discord.com/api/webhooks/WEBHOOK_ACL"
    },
    ["Anti - Godmode"] = {
        ["State"] = true,
        ["PunishType"] = "Ban",
        ["Webhook"] = "https://discord.com/api/webhooks/WEBHOOK_GODMODE"
    },
    ["Anti - Vehicle Health"] = {
        ["State"] = true,
        ["PunishType"] = "Ban",
        ["Webhook"] = "https://discord.com/api/webhooks/WEBHOOK_VEHICLE"
    },
    ["Anti - Explosions"] = {
        ["State"] = true,
        ["PunishType"] = "Kick",
        ["Webhook"] = "https://discord.com/api/webhooks/WEBHOOK_EXPLOSIONS"
    },
    ["Anti - Vehicle Explosions"] = {
        ["State"] = true,
        ["PunishType"] = "Kick",
        ["Webhook"] = "https://discord.com/api/webhooks/WEBHOOK_VEH_EXPLOSIONS"
    },
    ["Anti - Stop Resources"] = {
        ["State"] = true,
        ["PunishType"] = "Ban",
        ["Webhook"] = "https://discord.com/api/webhooks/WEBHOOK_STOP_RESOURCES"
    },
    ["Anti - Trigger Spam"] = {
        ["State"] = true,
        ["PunishType"] = "Kick",
        ["Webhook"] = "https://discord.com/api/webhooks/WEBHOOK_TRIGGER"
    },
    ["Anti - Paste Detection"] = {
        ["State"] = true,
        ["PunishType"] = "Ban",
        ["Webhook"] = "https://discord.com/api/webhooks/WEBHOOK_PASTE"
    },
    ["Anti - Remove Weapons"] = {
        ["State"] = true,
        ["PunishType"] = "Kick", -- Kick, Ban o None
        ["Webhook"] = "https://discord.com/api/webhooks/WEBHOOK_REMOVE_WEAPONS"
    },
    ["Anti - Remove Explosives"] = {
        ["State"] = true,
        ["PunishType"] = "Kick", -- Kick, Ban o None
        ["Webhook"] = "https://discord.com/api/webhooks/WEBHOOK_REMOVE_EXPLOSIVES"
    },
    ["Player Join/Quit"] = {
        ["State"] = false, -- true para activar, false para desactivar
        ["PunishType"] = "None", -- No aplica castigo
        ["Webhook"] = "https://discordapp.com/api/webhooks/1414664290413314169/OfO11OcYgAEAsWbdAOmJH_NIj7u074tgxC-kvN2T1b5M71Fwe5c0ilyWWnkEOpwnClYL"
    },
}

-- ====================================
-- 🚫 ARMAS PROHIBIDAS
-- (ID, Estado, Nombre)
-- ====================================
BlockedWeapons = {
    {35, true, "Rocket Launcher"},
    {36, true, "Rocket Launcher HS"},
    {37, true, "Lanzallamas"},
    {38, true, "Minigun"},
}

-- ====================================
-- 💣 EXPLOSIVOS PROHIBIDOS
-- (ID, Estado, Nombre)
-- ====================================
BlockedExplosives = {
    {16, true, "Granada"},
    {17, true, "Gas Lacrimógeno"},
    {18, true, "Molotov"},
    {39, true, "C4 (Satchel)"},
    {40, true, "Detonador"},
}

-- ====================================
-- ✅ ELEMENT DATA PERMITIDOS
-- ====================================
whitelistedElementData = {
    ['wheel_rotation.Data'] = true,
    ['hedit:saved'] = true,
    ['REPAIR:isAttachedEvent'] = true,
    ['ID'] = true,
    ['Arma'] = true,
    ['apontar'] = true,
    ['Level'] = true,
    ['XP'] = true,
    ['isPlayerInCamHackMode'] = true,
    ['ArmaSniper'] = true,
    ['AnonAdmin'] = true,
    ['skin'] = true,
    ['HS:points'] = true,
    ['HS>Falando'] = true,
    ['HS:panel:open'] = true,
    ['marker_id'] = true,
    ['HS>ModoVoz'] = true,
    ['timer.message'] = true,
    ['HS:neon'] = true,
    ['bloqInterface'] = true,
    ['isMeatInHand'] = true,
    ['isBoxInHand'] = true,
    ['fps'] = true,
    ['painelAberto'] = true,
    ['skydiving'] = true,
    ['custom:create_weapon'] = true,
    ['pointFinger'] = true, 
    ['REPAIR:attachServer'] = true,
    ['AFK'] = true,
    ['player:fps'] = true, 
    ['Difuz > show'] = true,
    ['Difuz > show hud'] = true,
    ['Fps'] = true,
    ['isTalking'] = true,
    ['radio.talking'] = true,
    ['tuning.nitroLevel'] = true,
}

-- Función para comprobar si un elementData está permitido
function isElementDataWhitelisted(dataName)
    return whitelistedElementData[dataName] or false
end
